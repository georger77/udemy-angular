import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-server',
  templateUrl: './server.component.html',
  styleUrls: ['./server.component.css']
})
export class ServerComponent implements OnInit {

  userName = '';
  isUserNameEmpty = true;
  constructor() {

  }

  ngOnInit(): void {
  }
onUpdateServerName(event: Event) {
   this.userName = (<HTMLInputElement>event.target).value;
   this.userName === '' ? this.isUserNameEmpty = true : this.isUserNameEmpty = false;
}
  onSendRespond() {
    this.userName = '';
    this.isUserNameEmpty = true;
  }
}



