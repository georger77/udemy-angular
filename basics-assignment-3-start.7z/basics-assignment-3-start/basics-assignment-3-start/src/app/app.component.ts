

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  // styleUrls: ['./app.component.css']
  styles: [`
.whiteClass{
    color:white;
  }
  `]
})
export class AppComponent {
  hiddenInfo = true;
  nameButton = 'Display Details';
  clicks = [];
  element = 0;
  onClickDisplayOrHiddenDetails() {
    this.hiddenInfo = !this.hiddenInfo;
    this.nameButton = (this.hiddenInfo === true) ? 'Display Details' : 'Hidden Details';
    this.clicks.push(this.element);
    this.element++;
  }
  getColor(x) {
    return x >= 5 ? 'blue' : 'none';
  }
  getCount(x) {
    return x >= 5;
  }
}

